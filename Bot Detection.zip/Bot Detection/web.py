from pycaret.classification import *
import streamlit as st
from streamlit_option_menu import option_menu
import pandas as pd
import webbrowser
import matplotlib.pyplot as plt

st.set_page_config(page_title='User Profile Classification', layout='wide')

# fungsi untuk melakukan prediksi
def predict(model, input_df):
    predictions_df = predict_model(model, data=input_df)
    st.write(predictions_df)
    profile_class = predictions_df['prediction_label'][0]
    return profile_class

def explain_owner():
    st.title('Yeorobun, hello! ☘')
    st.subheader("Get to know me")
    st.info("""
    I'm Abdul Muffid, diving deep into the world of data as a student majoring in Applied Data Science at the Electronic Engineering Polytechnic Institute of Surabaya. Beyond just hitting the books, I'm genuinely captivated by the endless possibilities data offers across different fields.
    
    You might be wondering about this web platform I've whipped up. Well, it's not just a random project—it's part of my journey in MLOps (that's Machine Learning Operations). This web serves classification models for making predictions. It's pretty cool stuff, and I'm excited to see where it takes me. Feel free to explore around and see what insights we can uncover together!
    """)

    st.subheader('Catch me now!')
    socmed_option = option_menu(
        menu_title=None,
        options=["Instagram", "GitHub", "LinkedIn"],
        icons=["instagram", "github", "linkedin"],
        orientation="horizontal",
        styles={"nav-link-selected": {"background-color": "lightblue"}},
    )

    if socmed_option:
        if socmed_option == "Instagram":
            if st.button("Visit Instagram"):
                webbrowser.open_new_tab("https://www.instagram.com/abd_muffid")
        elif socmed_option == "GitHub":
            if st.button("Visit GitHub"):
                webbrowser.open_new_tab("https://github.com/abdmuffid")
        elif socmed_option == "LinkedIn":
            if st.button("Visit LinkedIn"):
                webbrowser.open_new_tab("https://www.linkedin.com/in/abdul-muffid-9065b3246")

def explain_dataset():
    st.title("User Dataset")
    st.subheader("About Dataset")
    st.info("""
    This dataset includes user-related information such as Name, Username, Bio, Profile Image, Age of Account, Tweet Count, Following, and Followers. These features can be used to predict certain characteristics of the user account or classify the profile into different categories.
    """)

def display_summary_statistics(data):
    st.subheader("Statistic Descriptive")
    st.write("Statistic Descriptive for numerical features:")
    st.write(data.describe())

def display_features_importance(model):
    feature_importance = model.feature_importances_
    features = data.columns[:-1]
    sorted_indices = feature_importance.argsort()[::-1]
    sorted_features = [features[i] for i in sorted_indices]
    sorted_importance = feature_importance[sorted_indices]

    plt.figure(figsize=(10, 6))
    plt.barh(sorted_features, sorted_importance, color='skyblue')
    plt.xlabel('Importance')
    plt.ylabel('Features')
    plt.title('Feature Importance')
    plt.gca().invert_yaxis()
    st.pyplot(plt)

# Fungsi untuk menjelaskan model
def explain_model():
    st.title("Random Forest Classifier")
    st.info("Random Forest is a popular and powerful ensemble learning method used for classification tasks in machine learning.")
    st.subheader("Setup Model")
    setups = pull()
    st.write(setups)

    st.subheader("Features Importance")
    display_features_importance(model)

def predict_profile():
    st.title("Predict Your Profile Class!")
    st.subheader('Input your profile details below:')

    # Input data secara manual
    name = st.text_input('Name')
    username = st.text_input('Username')
    bio = st.text_area('Bio')
    profile_image = st.text_input('Profile Image URL')
    age_account = st.number_input('Age of Account (years)', min_value=0, max_value=100, value=1)
    tweet_count = st.number_input('Tweet Count', min_value=0, value=0)
    following = st.number_input('Following Count', min_value=0, value=0)
    followers = st.number_input('Followers Count', min_value=0, value=0)

    if st.button("Predict"):
        input_dict = {'Name': name,
                      'Username': username,
                      'Bio': bio,
                      'Profile Image': profile_image,
                      'Age Account': age_account,
                      'Tweet Count': tweet_count,
                      'Following': following,
                      'Followers': followers}
        input_df = pd.DataFrame([input_dict])
        output = predict(model=model, input_df=input_df)

        st.success(f'Profile classification: {output}')

def run():
    with st.sidebar:
        selected = option_menu(
            menu_title=None,
            options=["Introduction", "Information", "Prediction"],
            icons=["person-fill", "clipboard-data", "stars"],
            default_index=0,
            styles={"nav-link-selected": {"background-color": "lightblue"}},
        )

    st.sidebar.warning("Yo, check out this dope web app for predicting user profile classes!")
    st.sidebar.success("Abdul Muffid - 3322600021 - SDT 2022")

    if selected == "Introduction":
        explain_owner()
    elif selected == "Information":
        tab_data, tab_model = st.tabs(["Dataset Info", "Explain Model"])
        with tab_data:
            explain_dataset()
        with tab_model:
            explain_model()
    elif selected == "Prediction":
        predict_profile()

if __name__ == '__main__':
    run()
